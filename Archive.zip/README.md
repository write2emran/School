# School Management Portal for Madarsa

<p>Dashboard</p>
Attendance
Student Details log
Exam
Fees
Staff

